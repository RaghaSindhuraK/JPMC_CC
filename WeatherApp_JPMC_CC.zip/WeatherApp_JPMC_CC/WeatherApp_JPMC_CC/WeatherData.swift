//
//  WeatherData.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/30/24.
//

import Foundation
struct WeatherModel {
    let conditionId:Int
    let cityname: String
    let temperature: Double
    
    var temperatureString: String {
        return String(format: "%.1f", temperature)
    }
}
