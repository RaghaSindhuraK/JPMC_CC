//
//  WeatherViewModel.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/30/24.
//

import Foundation

struct WeatherViewModel {
    
    var weatherDataManager = WeatherDataManager()
    var weatherModel: WeatherSearchDataModel?
    
    func fecthWeatherByCity() {
        weatherDataManager.fetchWeather(with: "Dallas") { model in
            
            
        }
        
    }
    func fetchWeatherBylocation() {
        weatherDataManager.fetchWeatherbyLocation(lattitude: 44.33, longitude: 10.99) { model in
            
        }
    }
}
