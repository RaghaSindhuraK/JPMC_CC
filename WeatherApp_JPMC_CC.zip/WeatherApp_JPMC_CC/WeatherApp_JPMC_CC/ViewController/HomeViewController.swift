//
//  HomeViewController.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/29/24.
//

import UIKit

class HomeViewController: UIViewController {
    
    let recentSearchViewModel = RecentSearchViewModel()


    @IBOutlet weak var recentSearchHistory: UITableView!
    
    @IBAction func searchBycityPressed(_ sender: Any) {
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Refresh home screen with recent search
        recentSearchViewModel.getHistory()
        recentSearchHistory.reloadData()
    }

}

extension HomeViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recentSearchViewModel.rows
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = recentSearchViewModel.cityName(at: indexPath.row)
        return cell
    }
}


