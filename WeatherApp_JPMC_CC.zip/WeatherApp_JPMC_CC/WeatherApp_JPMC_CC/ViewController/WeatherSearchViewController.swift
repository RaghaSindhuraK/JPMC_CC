//
//  WeatherSearchViewController.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/30/24.
//

import Foundation
import UIKit
import CoreLocation



class WeatherSearchViewController: UIViewController, WeatherViewRefresh {
    
    
    func refreshView() {
        cityNameLabel.text = weatherViewModel.cityName
        temperatureLabel.text = weatherViewModel.temperatureLabel
        conditionDescription.text = weatherViewModel.weatherCondition
        tempMax.text = weatherViewModel.maxTemperature
        tempMin.text = weatherViewModel.minTemperature
        weatherView.isHidden = false
    
        conditionImage.loadImage(with: weatherViewModel.imageUrl)
    }
    
    func refreshFailed() {
        weatherView.isHidden = true
        
        let alert = UIAlertController(title: "Something went wrong", message: "Please enter a valid city name in US or try again later", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
    }
    
    var weatherViewModel = WeatherViewModel()
    
    @IBOutlet weak var weatherView: UIStackView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBAction func currentLocation(_ sender: UIButton) {
        // Method to get current location weather on VM
        weatherViewModel.fetchWeatherBylocation()
    }
    
    @IBOutlet weak var cityNameLabel: UILabel!
    
    @IBOutlet weak var temperatureLabel: UILabel!
    
    
    @IBOutlet weak var conditionDescription: UILabel!
    
    @IBOutlet weak var tempMin: UILabel!
    
    @IBOutlet weak var conditionImage: UIImageView!
    
    @IBOutlet weak var tempMax: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        weatherViewModel.delegate = self
        weatherView.isHidden = true
        
        // Method to get current location weather on VM
        weatherViewModel.fetchWeatherBylocation()
    }
    
}

extension WeatherSearchViewController : UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let text = searchBar.text,
        text != "" else { return }
        
        searchBar.resignFirstResponder()
        
        weatherViewModel.fecthWeatherByCity(searchText: text)
    }
}

// Fetch image using image url
extension UIImageView {
    func loadImage(with urlString: String) {
        guard let url = URL(string: urlString) else { return }
        
        let cache = URLCache.shared
        let request = URLRequest(url: url)
        
        // Check if image is present in URLCache
        if let data = cache.cachedResponse(for: request)?.data {
            self.image = UIImage(data: data)
        } else {
            URLSession.shared.dataTask(with: request) { data, urlResponse, error in
                DispatchQueue.main.async {
                    guard let responseData = data,
                          let urlresponse = urlResponse,
                          error == nil else {
                        DispatchQueue.main.async {
                            self.image = nil
                        }
                        return
                    }
                    
                    // Store image in URLCache
                    cache.storeCachedResponse(CachedURLResponse(response: urlresponse, data: responseData), for: request)
                    
                    DispatchQueue.main.async {
                        self.image = UIImage(data: responseData)
                    }
                }
            }.resume()
        }
    }
}
    



