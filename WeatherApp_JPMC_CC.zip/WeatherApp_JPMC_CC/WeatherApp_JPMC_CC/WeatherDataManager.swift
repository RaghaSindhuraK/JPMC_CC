//
//  WeatherModel.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/29/24.
//

import Foundation
import CoreLocation

struct WeatherDataManager {
    
    let weatherURL = "https://api.openweathermap.org/data/2.5/weather?appid=5fa92007c2a200d6df84dbd8dc33c4f8"
    
    func fetchWeather(with cityName: String, completion: @escaping (WeatherSearchDataModel?) -> Void) {
        let urlString = "\(weatherURL)&q=\(cityName)"
        performRequest(with: urlString, completion: completion)
    }
    
    func fetchWeatherbyLocation(lattitude: CLLocationDegrees, longitude: CLLocationDegrees, completion: @escaping  (WeatherSearchDataModel?) -> Void) {
        let urlString = "\(weatherURL)&lat=\(lattitude)&lon=\(longitude)"
        performRequest(with: urlString, completion: completion)
    }
    
    func performRequest( with urlString: String, completion: @escaping (WeatherSearchDataModel?) -> Void) {
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            let task = session.dataTask(with: url) { data, response, error in
                guard let responseData = data,
                      error == nil else {
                    completion(nil)
                    return
                }
                
                do {
                    let savedData = try JSONDecoder().decode(WeatherSearchDataModel.self, from: responseData)
                    completion(savedData)
                }
                catch { }
            }
            task.resume()
        }

    }
}
