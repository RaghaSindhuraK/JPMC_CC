//
//  RecentSearchDataManager.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/30/24.
//

import Foundation

let recentSearches = "Recent History"

class RecentSearchDataManager {
    // Get recent search from user defaults
    func getRecentSearch() -> [WeatherSearchDataModel] {
    
        guard let recentHistory = UserDefaults.standard.data(forKey: recentSearches) else {
            return [WeatherSearchDataModel]()
        }
        
        do {
            let decoder = JSONDecoder()
            let list = try decoder.decode([WeatherSearchDataModel].self, from: recentHistory)
            return list
        } catch {}
        
        return [WeatherSearchDataModel]()
    }
}
