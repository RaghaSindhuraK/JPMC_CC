//
//  WeatherModel.swift
//  WeatherApp_JPMC_CC
//
//  Created by Ragha Sindhura Kurella Venkata Subba on 8/29/24.
//

import Foundation
import CoreLocation

class WeatherDataManager: NSObject, CLLocationManagerDelegate {
    var locationManger:CLLocationManager?
    var completionHandler: ((WeatherSearchDataModel?) -> Void)?
    let weatherURL = "https://api.openweathermap.org/data/2.5/weather?appid=5fa92007c2a200d6df84dbd8dc33c4f8"
    
    func fetchWeather(with cityName: String, completion: @escaping (WeatherSearchDataModel?) -> Void) {
        let urlString = "\(weatherURL)&q=\(cityName)"
        performRequest(with: urlString, completion: completion)
    }
    
    func fetchWeatherbyLocation(lattitude: CLLocationDegrees, longitude: CLLocationDegrees, completion: @escaping  (WeatherSearchDataModel?) -> Void) {
        let urlString = "\(weatherURL)&lat=\(lattitude)&lon=\(longitude)"
        performRequest(with: urlString, completion: completion)
    }
    
    func performRequest( with urlString: String, completion: @escaping (WeatherSearchDataModel?) -> Void) {
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            let task = session.dataTask(with: url) { data, response, error in
                DispatchQueue.main.async {
                    guard let responseData = data,
                          error == nil else {
                        completion(nil)
                        return
                    }
                    
                    do {
                        let savedData = try JSONDecoder().decode(WeatherSearchDataModel.self, from: responseData)
                        completion(savedData)
                        self.storeRecentSearch(model: savedData)
                    }
                    catch { }
                }
            }
            task.resume()
        }
        
    }
    
    private func storeRecentSearch(model: WeatherSearchDataModel) {
        guard let recentHistory = UserDefaults.standard.data(forKey: recentSearches) else {
            do {
                let encoder = JSONEncoder()
                let data = try encoder.encode([model])
                UserDefaults.standard.setValue(data, forKey: recentSearches)
            } catch {}
            
            return
        }
        
        do {
            let decoder = JSONDecoder()
            var list = try decoder.decode([WeatherSearchDataModel].self, from: recentHistory)
            list.append(model)
            
            let encoder = JSONEncoder()
            let data = try encoder.encode(list)
            UserDefaults.standard.setValue(data, forKey: recentSearches)
        } catch {}
    }
    
    func getWeatherForCurrentLocation(completion: @escaping (WeatherSearchDataModel?) -> Void) {
        completionHandler = completion
        locationManger = CLLocationManager()
        locationManger?.delegate = self
        locationManger?.requestAlwaysAuthorization()
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            manager.startUpdatingLocation()
        default:
            break
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        manager.stopUpdatingLocation()
        guard let latitude = locations.first?.coordinate.latitude,
              let longitude = locations.first?.coordinate.longitude,
              let unwrappedCompletion = completionHandler
            
        else { return }
        
        
        fetchWeatherbyLocation(lattitude:latitude, longitude: longitude, completion: unwrappedCompletion)
    }
    
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: any Error) {
        manager.stopUpdatingLocation()
    }
    
    
}
